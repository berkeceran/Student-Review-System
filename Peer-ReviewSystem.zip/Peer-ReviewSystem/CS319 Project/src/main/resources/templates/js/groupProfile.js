document.getElementById("members").innerHTML = "";

function myFunction() {
    localStorage.removeItem("navigated");
    if(localStorage.getItem("userRole") === "student") {
        document.getElementById("dashboardType").href = "DashboardStudent.html";
    } else {
        document.getElementById("dashboardType").href = "DashboardInstructor.html";
    }
    // Get current semester
    let httpRequest1 = new XMLHttpRequest();
    httpRequest1.overrideMimeType("application/json");
    httpRequest1.open("GET", 'http://localhost:8080/CurrentSystemInfoController/getCurrentSemester');
    httpRequest1.onload = function () {
        let result = httpRequest1.responseText;
        document.getElementById("semesterName").innerHTML = result;  // assign semester
        // Get Current Course
        let httpRequest2 = new XMLHttpRequest();
        httpRequest2.overrideMimeType("application/json");
        httpRequest2.open("GET", 'http://localhost:8080/CurrentSystemInfoController/getCurrentCourseName');
        httpRequest2.onload = function () {
            result = httpRequest2.responseText;
            document.getElementById("courseName").innerHTML = localStorage.getItem("courseName");  // assign course name
            arrangeTheUI();
        }
        httpRequest2.send();
    }
    httpRequest1.send();
}

function arrangeTheUI() {
    let groupID = localStorage.getItem("navigatedGroup");
    // If user enters his own group page
    if (groupID === null) {
        getGroupOfUser();
    } else {
        arrangeButtons();
    }
}

// Get users group name
function getGroupOfUser() {
    let httpRequest = new XMLHttpRequest();
    let studentID = parseInt(localStorage.getItem("id"));
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/ProfileController/getStudentsGroup?studentID='+studentID);
    httpRequest.onload = function () {
        let groupId = httpRequest.responseText;
        localStorage.setItem("navigatedGroup", groupId);
        localStorage.setItem("navigated", "false");
        arrangeButtons();
    }
    httpRequest.send();
}

// The button will be arranged (hidden or display) according to the user entering the profile.
function arrangeButtons() {
    // Assign name of group to the html
    document.getElementById("Groupname").innerHTML = localStorage.getItem("navigatedGroup"); // assign current group

    // If the group formation status is off, then buttons should be invisible to all users
    // Group formation status
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/ProcessController/getGroupFormationStatus?');
    httpRequest.onload = function () {
        let status = httpRequest.responseText;
        if(status === "off") {
            document.getElementById("LeaveGroup").style.visibility = "hidden";
            document.getElementById("inviteMemberID").style.visibility = "hidden";
            document.getElementById("deleteMemberID").style.visibility = "hidden";
            if(localStorage.getItem("navigated") === null) {
                document.getElementById("row4").style.visibility = "hidden";
            }
        } else {
            if(localStorage.getItem("navigated") !== "false") {
                // Hide button for non-members
                document.getElementById("LeaveGroup").style.visibility = "hidden";
                document.getElementById("row4").style.visibility = "hidden";
                if(localStorage.getItem("userRole") === "student" && localStorage.getItem("navigated") !== "false") {
                    document.getElementById("inviteMemberID").style.visibility = "hidden";
                    document.getElementById("deleteMemberID").style.visibility = "hidden";
                }
            }
        }
        getGithubLink();
    }
    httpRequest.send();
    // Hide functional button that are used by group members
}

// This method will get the github link
function getGithubLink() {
    let httpRq = new XMLHttpRequest();
    httpRq.overrideMimeType("application/json");
    let groupName = localStorage.getItem("navigatedGroup");
    httpRq.open("GET", 'http://localhost:8080/GroupFormationController/getGithubLink?groupName='+groupName);
    httpRq.onload = function () {
        let result = httpRq.responseText;
        let json = JSON.parse(result);
        let createA = document.createElement('a');
        createA.setAttribute('href', json["link"]);
        createA.setAttribute("target", "_blank");
        let createLabel = document.createElement("P");
        createLabel.innerText = json["description"];
        createA.innerText = json["link"];
        document.getElementById("groupDescription").append(createLabel);
        document.getElementById("groupDescription").append(createA);
        getMembers();
    }
    httpRq.send();
}

// Get members of group
function getMembers() {
    let group = localStorage.getItem("navigatedGroup");
    let httpRequest1 = new XMLHttpRequest();
    httpRequest1.overrideMimeType("application/json");
    httpRequest1.open("GET", 'http://localhost:8080//GroupFormationController/getGroupMembers?groupID='+group);
    httpRequest1.onload = function () {
        let response = httpRequest1.responseText;
        let members = JSON.parse(response);
        let group = {member: members, name: localStorage.getItem("navigatedGroup")};
        // Create single section li
        let li_Group = document.createElement("LI");
        li_Group.value = group.name;
        let buttonGroup = document.createElement('button');
        buttonGroup.innerText = group.name;
        li_Group.append(buttonGroup);
        // For each group in section, the new li will be created.
        buttonGroup.onclick = function () {
            if (document.getElementById("members").innerHTML !== "") {
                document.getElementById("members").innerHTML = "";
            } else {
                group.member.forEach(function (element) {
                    let li_member = document.createElement("LI");
                    li_member.value = element;
                    let buttonMember = document.createElement('button');
                    buttonMember.innerText = element;
                    li_member.append(buttonMember);
                    buttonMember.onclick = function () {
                        if(localStorage.getItem("navigated") !== null) {
                            localStorage.removeItem("navigatedGroup");
                        }
                        localStorage.removeItem("navigated");
                        localStorage.setItem("navigatedStudent", element);
                        window.location.href = "StudentProfile.html";
                    };
                    document.getElementById("members").appendChild(li_member);
                });
            }
        };
        document.getElementById("member-list").append(li_Group);
        getArtifactReviews();
    }
    httpRequest1.send();
}

// Add github link and artifact
function addGithubLink() {
    let link = document.getElementById("gitUrl").value;
    let groupName = localStorage.getItem("navigatedGroup");
    let description = document.getElementById("coments").value;
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/GroupFormationController/addGithubLink?link='+link+'&groupName='+groupName+'&description='+description);
    httpRequest.onload = function () {
        if(localStorage.getItem("navigated") !== null) {
            localStorage.removeItem("navigatedGroup");
        }
        localStorage.removeItem("navigated");
        window.location.reload();
    }
    httpRequest.send();
}

// Leave group
function leaveGroup() {
    let studentID = parseInt(localStorage.getItem("id"));
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/GroupFormationController/removeUserFromGroup?studentID='+studentID);
    httpRequest.onload = function () {
        if(localStorage.getItem("navigated") !== null) {
            localStorage.removeItem("navigatedGroup");
        }
        localStorage.removeItem("navigated");
        window.location.href = "DashboardStudent.html";
    }
    httpRequest.send();
}

// Add member to group
function addMemberToGroup() {
    //int studentID, String groupName,int sectionID
    let groupName = localStorage.getItem("navigatedGroup");
    let studentID = parseInt(document.getElementById("invitedId").value);
    let sectionID = parseInt(localStorage.getItem("section"));
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/GroupFormationController/notRandomGeneratorAddMember?studentID='+studentID+'&groupName='+groupName+'&sectionID='+sectionID);
    httpRequest.onload = function () {
        if(localStorage.getItem("navigated") !== null) {
            localStorage.removeItem("navigatedGroup");
        }
        localStorage.removeItem("navigated");
        window.location.reload();
    }
    httpRequest.send();
}

// Remove member from group
function removeUserFromGroup() {
    // Remove student text varsayimsal bir id, kutuya ne verdiyseniz ekleyin
    let studentID = parseInt(document.getElementById("deletedId").value);
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/GroupFormationController/removeUserFromGroup?studentID='+studentID);
    httpRequest.onload = function () {
        if(localStorage.getItem("navigated") !== null) {
            localStorage.removeItem("navigatedGroup");
        }
        localStorage.removeItem("navigated");
        window.location.reload();
    }
    httpRequest.send();
}

// Add artifact Reviews
function addArtifactReview() {
    let groupName = localStorage.getItem("navigatedGroup");
    let artifactType = document.getElementById("artifactName").value;
    let answer = document.getElementById("content").value;
    // If user is in its own group, then he/she cannot give artifact review.
    let giverID = parseInt(localStorage.getItem("id"));
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/ArtifactReviewController/giveArtifactReviewToGroup?groupName='+groupName+'&artifactType='+artifactType+'&answer='+answer+'&giverID='+giverID);
    httpRequest.onload = function () {
        if(localStorage.getItem("navigated") !== null) {
            localStorage.removeItem("navigatedGroup");
        }
        localStorage.removeItem("navigated");
        window.location.reload();
    }
    httpRequest.send();
}

// Get artifact Reviews
function getArtifactReviews() {
    let groupName = localStorage.getItem("navigatedGroup");
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/ArtifactReviewController/getArtifactReviewFromGroup?groupName='+groupName);
    httpRequest.onload = function () {
        let response = httpRequest.responseText;
        let reviews = JSON.parse(response);
        reviews.forEach(function(element) {
            let giverID = element["giverID"];
            let artifactReview = element["artifactReview"];
            let artifactType = element["artifactType"];
            // let li = document.getElementById("LI");
            // li.value = element;
            let ul = document.getElementById("reviews");
            let li = document.createElement("li");

            li. appendChild(document.createTextNode(artifactType + " - " + giverID + " : " + artifactReview));
            ul. appendChild(li);

            // li.innerText = giverID;
            // li.innerText = artifactType;
            document.getElementById("reviews").appendChild(li);
        });
    }
    httpRequest.send();
}

function goToDashBoard() {
    if(localStorage.getItem("userRole") === "student") {
        window.location.href = "DashboardStudent.html";
    } else {
        window.location.href = "DashboardInstructor.html";
    }
}