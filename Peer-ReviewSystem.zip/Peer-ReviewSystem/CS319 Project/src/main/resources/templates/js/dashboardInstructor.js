// Remove the navigation if instructor comes from someones profile.
localStorage.removeItem("navigatedStudent");
localStorage.removeItem("navigatedGroup");
document.getElementById("group-list").innerHTML="";

function getInformation () {
    let result1;
    let httpRequest1 = new XMLHttpRequest();
    httpRequest1.overrideMimeType("application/json");
    httpRequest1.open("GET", 'http://localhost:8080/CurrentSystemInfoController/getAllInformation');
    httpRequest1.onload = function () {
        result1 = JSON.parse(httpRequest1.responseText);
        localStorage.setItem("semester", result1["semester"]);
        document.getElementById("semesterName").innerHTML = result1["semester"];
        document.getElementById("courseName").innerHTML = result1["courseName"];
        document.getElementById("instructorFullName").innerHTML = localStorage.getItem("name") + " " + localStorage.getItem("surname");
        document.getElementById("currentSection").innerHTML = "Current Section: " + localStorage.getItem("currentSection");
        localStorage.setItem("courseName", result1["courseName"]);
        getStatus();
    }
    httpRequest1.send();
}

function getStatus() {
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/ProcessController/getAllProcessInformation?');
    httpRequest.onload = function () {
        let result = JSON.parse(httpRequest.responseText);
        if(result["peerReview"] === "on") {
            document.getElementById("activatePeerReview").checked = true;
        }
        if(result["formation"] === "on") {
            document.getElementById("activateGroupFormation").checked = true;
        }
        if(result["courseReview"] === "on") {
            document.getElementById("activateCourseReview").checked = true;
        }
        getSectionsAndGroups();
    }
    httpRequest.send();
}

function getSectionsAndGroups() {
    let sections = JSON.parse(localStorage.getItem("sections"));

    sections.forEach(function (sectionNumber) {
        // Get groups of each section that instructor is enrolled.
        let httpRequest = new XMLHttpRequest();
        httpRequest.overrideMimeType("application/json");
        httpRequest.open("GET", 'http://localhost:8080//SectionController/getGroupsOfSection?sectionNumber='+parseInt(sectionNumber));
        httpRequest.onload = function () {
            let groups = JSON.parse(httpRequest.responseText);
            let section = {group: groups, name: sectionNumber};
            // Create single section li
            let LI_section = document.createElement("LI");
            LI_section.value = section.name;
            let LI_Button = document.createElement('button'); // For sections
            LI_Button.innerText = section.name;
            LI_section.append(LI_Button);
            // For each group in section, the li will be created
            LI_Button.onclick = function() {
                localStorage.setItem("currentSection", sectionNumber);
                document.getElementById("currentSection").innerHTML = "Current Section: " + localStorage.getItem("currentSection");
                if(document.getElementById("group-list").innerHTML!==""){
                    document.getElementById("group-list").innerHTML="";
                } else {
                    section.group.forEach(function(gr) {
                        let li_Group = document.createElement("LI");
                        li_Group.value = gr;
                        let buttonGroup = document.createElement('button');
                        buttonGroup.innerText = gr;
                        li_Group.append(buttonGroup);   // For each group in section
                        buttonGroup.onclick = function() {
                            localStorage.setItem("navigatedGroup", gr);
                            window.location.href="GroupProfile.html";
                        };
                        document.getElementById("group-list").appendChild(li_Group);
                    });
                }
            };
            document.getElementById("section-list").appendChild(LI_section);
        }
        httpRequest.send();
    });
}

function sendMessage(){
    let message1 = document.getElementById("usermsg").value;
    let li = document.createElement("LI");
    li.innerHTML = message1;
    li.value= message;
    if(li.innerHTML !== ""){
        document.getElementById("messages").appendChild(li);
    }

    console.log(li.innerHTML);
    document.getElementById("usermsg").value = "";
}

function logoutSystem() {
    localStorage.clear();
}

//Pop up instructor start group formation
// Get the modal
let modal = document.getElementById("myModal");

// Get the button that opens the modal
let btn = document.getElementById("groupFormB");

// Get the <span> element that closes the modal
let span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
if(modal!== null){
    btn.onclick = function() {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    }
}

function randomForm() {
    let size = parseInt(document.getElementById("quantity").value);
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080//GroupFormationController/randomGeneratorAllSections?size='+size);
    httpRequest.onload = function () {
    }
    httpRequest.send();
}

function manualForm(){
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080//ProcessController/changeGroupFormation?status=on');
    httpRequest.onload = function () {}
    httpRequest.send();
}
//pop-up end
let activatePeerReview = document.getElementById("activatePeerReview");
activatePeerReview.onclick =  function() {
    let status;
    if(activatePeerReview.checked === true) {
        status='on';
    } else {
        status='off';
    }
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080//ProcessController/changePeerReview?status='+status);
    httpRequest.send();
};

let activateGroupFormation = document.getElementById("activateGroupFormation");

activateGroupFormation.onclick = function () {
    let status;
    if(activateGroupFormation.checked === true) {
        status='on';
    } else {
        status='off';
    }
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080//ProcessController/changeGroupFormation?status='+status);
    httpRequest.send();
};

let activateCourseReview = document.getElementById("activateCourseReview");

activateCourseReview.onclick = function () {
    let status;
    if(activateCourseReview.checked === true) {
        status='on';
    } else {
        status='off';
    }
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080//ProcessController/changeCourseReview?status='+status);
    httpRequest.send();
};