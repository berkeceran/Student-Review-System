localStorage.removeItem("navigatedStudent");
localStorage.removeItem("navigatedGroup");
document.getElementById("group-list").innerHTML="";
// course name
function getInformation() {
    // Get information about peer review period in order to display or hide buttons
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/ProcessController/getAllProcessInformation?');
    httpRequest.onload = function () {
        let result = JSON.parse(httpRequest.responseText);

        if(result["peerReview"] === "off") {
            document.getElementById("AssignPeerReview").style.visibility = "hidden";
        }
        if(result["formation"] === "off") {
            document.getElementById("groupCreate").style.visibility = "hidden";
        }
        if(result["courseReview"] === "off") {
            document.getElementById("CourseReview").style.visibility = "hidden";
        }

        // Get current Semester's name
        let result1;
        let httpRequest1 = new XMLHttpRequest();
        httpRequest1.overrideMimeType("application/json");
        httpRequest1.open("GET", 'http://localhost:8080/CurrentSystemInfoController/getCurrentSemester');
        httpRequest1.onload = function () {
            result1 = httpRequest1.responseText;
            localStorage.setItem("semester", result1);
            document.getElementById("semesterName").innerHTML = result1;

            // Get current Course Name
            let result2;
            let httpRequest2 = new XMLHttpRequest();
            httpRequest2.overrideMimeType("application/json");
            httpRequest2.open("GET", 'http://localhost:8080/CurrentSystemInfoController/getCurrentCourseName');
            httpRequest2.onload = function () {
                result2 = httpRequest2.responseText;
                document.getElementById("courseName").innerHTML = result2;
                localStorage.setItem("courseName", result2);

                // Get instructor's sections' groups
                let section = parseInt(localStorage.getItem("section"));
                let httpRequest3 = new XMLHttpRequest();
                httpRequest3.overrideMimeType("application/json");
                httpRequest3.open("GET", 'http://localhost:8080//SectionController/getGroupsOfSection?sectionNumber='+section);
                httpRequest3.onload = function () {
                    let response = httpRequest3.responseText;
                    let groups = JSON.parse(response);
                    let section = { group: groups , name: localStorage.getItem("section") };
                    // Create single section li
                    let li_Section = document.createElement("LI");
                    li_Section.value = section.name;
                    let buttonSection = document.createElement('button');
                    buttonSection.innerText = section.name;
                    li_Section.append(buttonSection);
                    // For each group in section, the new li will be created.
                    buttonSection.onclick = function() {
                        if(document.getElementById("group-list").innerHTML!==""){
                            document.getElementById("group-list").innerHTML="";
                        } else {
                            section.group.forEach(function(element) {
                                let li_Group = document.createElement("LI");
                                li_Group.value = element;
                                let buttonGroup = document.createElement('button');
                                buttonGroup.innerText = element;
                                li_Group.append(buttonGroup);
                                buttonGroup.onclick = function() {
                                    localStorage.setItem("navigatedGroup", element);
                                    window.location.href="GroupProfile.html";
                                };
                                document.getElementById("group-list").appendChild(li_Group);
                            });
                        }
                    };
                    document.getElementById("section-list").appendChild(li_Section);
                }
                httpRequest3.send();
            }
            httpRequest2.send();
        }
        httpRequest1.send();
    }
    httpRequest.send();

    //_______________________________
    document.getElementById("studentFullName").innerHTML = localStorage.getItem("name") + " " + localStorage.getItem("surname");
}

function gotoGroupProfile() {
    let studentID = localStorage.getItem("id");
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080//ProfileController/userHasGroup?studentID='+studentID);
    httpRequest.onload = function () {
        let answer = httpRequest.responseText;
        if(answer === "true") {
            window.location="GroupProfile.html";
        }
    }
    httpRequest.send();

}

function gotoPersonalProfile() {
    localStorage.setItem("navigatedStudent", localStorage.getItem("id"));
    window.location.href="StudentProfile.html";
}

function createGroup2(){
    let sectionID = parseInt(localStorage.getItem("section"));
    let studentID = parseInt(localStorage.getItem("id"));

    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080//GroupFormationController/notRandomGenerator?sectionID='+sectionID+'&studentID='+studentID);
    httpRequest.onload = function () {
        let json = JSON.parse(httpRequest.responseText);
        if (json["result"] === "true") {
            alert("You have created new group. If you encounter with any error, please contact with admin.");
            localStorage.setItem("groupId", json["group"]);
        }
        document.getElementById("myModal").style.visibility = "hidden";

    }
    httpRequest.send();
}

let modal = document.getElementById("myModal");

// Get the button that opens the modal
let createGroup = document.getElementById("groupCreate");

// Get the <span> element that closes the modal
let span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
if(modal!== null){
    createGroup.onclick = function() {
        modal.style.display = "block";
        let size = parseInt(document.getElementById("quantity").value);
        let httpRequest = new XMLHttpRequest();
        httpRequest.overrideMimeType("application/json");
        // section is 1, needs to be replaced
        httpRequest.open("GET", 'http://localhost:8080//GroupFormationController/randomGenerator?size='+size+'&sectionID='+parseInt(localStorage.getItem("section")));
        httpRequest.onload = function () {
            let output = httpRequest.responseText;
            alert("The reminder students are : " + output);
        }
        httpRequest.send();
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    }
}

function sendMessage() {
    let message1 = document.getElementById("usermsg").value;
    let li = document.createElement("LI");
    li.innerHTML = message1;
    li.value= message;
    if(li.innerHTML !== "") {
        document.getElementById("messages").appendChild(li);
    }
    console.log(li.innerHTML);
    document.getElementById("usermsg").value = "";
}

function logoutSystem() {
    localStorage.clear();
}