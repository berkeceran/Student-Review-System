function myFunction() {
    let schoolID = localStorage.getItem("navigatedStudent");
    if(schoolID !== localStorage.getItem("id")) {
        let httpRequest = new XMLHttpRequest();
        httpRequest.overrideMimeType("application/json");
        httpRequest.open("GET", 'http://localhost:8080//SignUpController/getUserInformation?schoolID='+schoolID);
        httpRequest.onload = function () {
            let userJSON = JSON.parse(httpRequest.responseText);
            document.getElementById("name").innerHTML = " Name : " + userJSON["name"];
            document.getElementById("surname").innerHTML = " Surname : " + userJSON["surname"];
            document.getElementById("Email").innerHTML = " Email : " + userJSON["email"];
            getStudentsSection(schoolID);
        }
        httpRequest.send();
    } else {
        document.getElementById("name").innerHTML = " Name : " + localStorage.getItem("name");
        document.getElementById("surname").innerHTML = " Surname : " + localStorage.getItem("surname");
        document.getElementById("Email").innerHTML = " Email : " + localStorage.getItem("email");
        getStudentsSection(localStorage.getItem("id"));
        if(localStorage.getItem("userRole") === "instructor" || localStorage.getItem("userRole") === "TA") {
            getAllPeerReviews();
        }
    }
    document.getElementById("Course").innerHTML = " Course : " + localStorage.getItem("courseName");
    document.getElementById("Semester").innerHTML = " Semester : " + localStorage.getItem("semester");

}

function getStudentsSection(studentID) {
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/SectionController/getSectionOfStudent?studentID='+studentID);
    httpRequest.onload = function () {
        let section = httpRequest.responseText;
        document.getElementById("Section").innerHTML = " Section : " + section;
        getGroupOfUser(studentID);
    }
    httpRequest.send();
}

// Get users group name
function getGroupOfUser(studentID) {
    let rq2 = new XMLHttpRequest();
    rq2.overrideMimeType("application/json");
    rq2.open("GET", 'http://localhost:8080/ProfileController/getStudentsGroup?studentID='+studentID);
    rq2.onload = function () {
        let groupId = rq2.responseText;
        document.getElementById("Group").innerHTML = " Group : " + groupId;
        localStorage.setItem("groupId", groupId);
        if(localStorage.getItem("userRole") !== "student")
        {
            getAllPeerReviews();
        }
    }
    rq2.send();
}

//for show how to use
function getAllPeerReviews() {
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    let groupID = localStorage.getItem("groupId")
    httpRequest.open("GET", 'http://localhost:8080/GroupFormationController/getGroupMembers?groupID='+groupID);
    httpRequest.onload = function () {
        let result = httpRequest.responseText;
        let json = JSON.parse(result);
        let students = [];
        let schoolID = localStorage.getItem("navigatedStudent");
        let rw = [];
        let i = 0;
        json.forEach(function (element)
        {
            i = i +1 ;
            if(element !== parseInt(schoolID)) {
                let httpRequest2 = new XMLHttpRequest();
                let rec = parseInt(localStorage.getItem("userID"));
                httpRequest2.overrideMimeType("application/json");
                httpRequest2.open("GET", 'http://localhost:8080//PeerReviewController/getPeerReviewAnswers?giverID='+parseInt(element)+'&receiverID='+parseInt(schoolID));
                httpRequest2.onload = function () {
                    let result = httpRequest2.responseText;
                    rw.push(result);
                    let student = { review: rw, name: element};
                    students.push(student);
                    if(i === json.length)
                    {
                        drawPeerCevap(students);
                    }
                }
                httpRequest2.send();
            }
        });
    }
    httpRequest.send();
}

function drawPeerCevap(students){
    students.forEach(function (student){
        let li = document.createElement("LI");
        li.value = student;
        let buttonE = document.createElement('button');
        buttonE.innerText = student.name;
        li.append(buttonE);
        buttonE.onclick = function() {
            if(document.getElementById("questions").innerHTML!==""){
                document.getElementById("questions").innerHTML="";
            }
            else {
                let li = document.createElement("LI");
                li.value = student.review;
                let label = document.createElement('label');
                label.innerText = student.review;
                li.append(label);
                document.getElementById("questions").appendChild(li);
            }
        };
        document.getElementById("students").appendChild(li);
    });
}

function doDashboard() {
    if(localStorage.getItem("userRole") === "student") {
        window.location.href = "DashboardStudent.html";
    } else {
        window.location.href = "DashboardInstructor.html";
    }
}