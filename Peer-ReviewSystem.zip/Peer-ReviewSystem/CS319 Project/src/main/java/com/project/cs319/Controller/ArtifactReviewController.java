package com.project.cs319.Controller;
import com.project.cs319.Entity.*;
import com.project.cs319.DataBase.*;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ArtifactReviewController")
public class ArtifactReviewController
{
    public static  mongoDB database;

    public ArtifactReviewController()
    {
        database = new mongoDB();
    }

    @GetMapping("/giveArtifactReviewToGroup")
    public String giveArtifactReviewToGroup(String groupName, String artifactType, String answer, int giverID)
    {
        if(database == null) { // Analsysis Design
            database = new mongoDB();
        }
        database = new mongoDB();
        return database.giveArtifactReviewToGroup(groupName, artifactType, answer, giverID) ? "true" : "false";
    }

    @GetMapping("/getArtifactReviewFromGroup")
    public String getArtifactReviewFromGroup(String groupName) throws JSONException {
        if(database == null) {
            database = new mongoDB();
        }
        String reviews= database.getArtifactReviewFromGroup(groupName);
        System.out.println("Reviews are : " + reviews);
        return reviews;
    }

}