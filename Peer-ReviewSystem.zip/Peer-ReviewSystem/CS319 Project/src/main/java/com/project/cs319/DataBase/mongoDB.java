package com.project.cs319.DataBase;
import com.mongodb.util.JSON;
import com.project.cs319.Entity.*;
import com.mongodb.BasicDBObject;
import com.project.cs319.Controller.*;
import com.mongodb.Cursor;
import com.mongodb.MongoClientURI;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.BsonArray;
import org.bson.Document;
import org.bson.conversions.Bson;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.Mongo;
import com.mongodb.WriteConcern;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSInputFile;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.print.Doc;
import java.sql.Array;
import java.sql.SQLOutput;
import java.util.*;
import java.io.File;
import java.io.IOException;

/**
 * This is the mongoDB class of the application
 * This class is the link between the actual database and the controller package
 */
public class mongoDB {

    // variables
    public  MongoClient mongoClient;
    public  MongoDatabase database;

    // collections of the database
    public  MongoCollection<Document> collectionUser;
    public  MongoCollection<Document> collectionSection;
    public  MongoCollection<Document> collectionGroups;
    public  MongoCollection<Document> collectionPeerReviewQuestions;
    public  MongoCollection<Document> collectionPeerReviewAnswer;
    public  MongoCollection<Document> collectionArtifactReviews;
    public  MongoCollection<Document> collectionCourseReviewQuestion;
    public  MongoCollection<Document> collectionCourseReviewAnswer;
    public  MongoCollection<Document> collectionProcess;
    public  MongoCollection<Document> collectionProjectRates;
    public  MongoCollection<Document> collectionCurrentSystemInfo;
    public  MongoCollection<Document> collectionContactRequest;
    public MongoCollection<Document> collectionForgetPasswordNotification;


    // the variable holds the passwords of the users
    public static Hashtable userPasswords;

    /**
     * This is the constructor of mongoDB class
     */
    public mongoDB() {
        try {
            mongoClient = MongoClients.create(
                    "mongodb+srv://berke:C-sSv!ABPHeUQ3p@peerreview.pixjl.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
            database = mongoClient.getDatabase("cs319");

            // gets the collections from the database
            collectionUser = database.getCollection("user");
            collectionSection = database.getCollection("section");
            collectionGroups = database.getCollection("groups");
            collectionPeerReviewQuestions = database.getCollection("peerReviewQuestion");
            collectionPeerReviewAnswer = database.getCollection("peerReviewAnswer");
            collectionArtifactReviews = database.getCollection("artifactReviews");
            collectionCourseReviewQuestion = database.getCollection("courseReviewQuestion");
            collectionCourseReviewAnswer = database.getCollection("courseReviewAnswer");
            collectionProcess = database.getCollection("process");
            collectionProjectRates = database.getCollection("projectRates");
            collectionCurrentSystemInfo = database.getCollection("currentSystemInfo");
            collectionContactRequest = database.getCollection("contactRequest");
            collectionForgetPasswordNotification = database.getCollection("forgetPasswordNotification");
            userPasswords = new Hashtable();

        } catch (Exception e) {

        }

    }

    // The methods of the database are divided specifically for the each controller class

    //---------------------------------------------------------------------------------------------------
    // ContactUsController
    //
    /**
     * This is the method for get the request from users who has forgotten their password
     * @param email the email of the user
     * @param schoolID the id of the user
     */
    public void performForgetPassword(String email, int schoolID)
    {
        if(getUser(schoolID) != null) {
            try {
                if (getUser(schoolID).getEmail().equals(email)) {
                    MongoCursor<Document> doc = collectionForgetPasswordNotification.find().iterator();
                    Document d1 = new Document();
                    d1.append("email", email);
                    d1.append("schoolID", schoolID);

                    System.out.println("performForgetPassword is okey");
                    collectionForgetPasswordNotification.insertOne(d1);
                }
            } catch (Exception e) {
                System.out.println("performForgetPassword has errors");
            }
        }

    }

    /**
     * This is the method for adding github link of the group
     * @param groupName the group name
     * @param description the description of the group
     */
    public void addGithubLink(String link, String groupName, String description) {
        try
        {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("groupName", groupName);
            MongoCursor<Document> cursor = collectionGroups.find(whereQuery).iterator();
            while(cursor.hasNext()) {
                ArrayList<Object> groupFormation = new ArrayList(cursor.next().values());

                Document found = (Document) collectionGroups.find(new Document("groupName", groupName)).first();

                Bson updateMember = new Document("githubLink", link);
                Bson updateOperation = new Document("$set", updateMember);
                collectionGroups.findOneAndUpdate(found, updateOperation);

                Document found1 = (Document) collectionGroups.find(new Document("groupName", groupName)).first();

                Bson updateMember1 = new Document("description", description);
                Bson updateOperation1 = new Document("$set", updateMember1);
                collectionGroups.findOneAndUpdate(found1, updateOperation1);

                System.out.println("addGithubLink ekleme tamam");
            }
        }catch (Exception e)
        {
            System.out.println("addGithubLink çalışmıyorr");
        }

    }

    /**
     * This is the method for getting github link of the group
     * @param groupName the group name
     * @return list which includes github link and description
     */
    public ArrayList<String> getGithubLink(String groupName) {
        try {

            Document doc = collectionGroups.find(new Document("groupName", groupName)).first();
            ArrayList<String> arr1 = new ArrayList<>();
            arr1.add(doc.getString("githubLink"));
            arr1.add(doc.getString("description"));
            System.out.println("Ifin disinda size1 : " + arr1.size());
            if(arr1.get(0) == null || arr1.get(0).equals("") ) {
                arr1.add("GitHub link is not available");
                arr1.add("Ups, no description yet.");
                return arr1;
            }
            return arr1;

        } catch (Exception e) {
            System.out.println("getCurrentCourseName hatalı");
            return null;
        }
    }

    /**
     * This is the method for deleting all the data from the database when semester is finished
     */
    public void deleteAllSemester()
    {
        try
        {
            BasicDBObject document = new BasicDBObject();
            // Delete All documents from collection Using blank BasicDBObject
            collectionContactRequest.deleteMany(document);
            collectionProjectRates.deleteMany(document);
            collectionPeerReviewQuestions.deleteMany(document);
            collectionPeerReviewAnswer.deleteMany(document);
            /*
            collectionUser.deleteMany(document);
            collectionSection.deleteMany(document);
            collectionGroups.deleteMany(document);


            collectionArtifactReviews.deleteMany(document);
            collectionCourseReviewQuestion.deleteMany(document);
            collectionCourseReviewAnswer.deleteMany(document);
            collectionProcess.deleteMany(document);

            collectionCurrentSystemInfo.deleteMany(document);
            collectionContactRequest.deleteMany(document);
            collectionForgetPasswordNotification.deleteMany(document);

*/
            System.out.println("deleteAllSemester çalışıyorrrrrrr");
        }catch (Exception e)
        {
            System.out.println("deleteAllSemester çalışmıyorrr");
        }

    }



    /**
     * This is the method for adding a contact request from a user to database
     * @param name the name of the contactor
     * @param email the email of the contactor
     * @param howFound the way the contactor finds the application
     * @param message of the user
     */

    public void addContactRequest(String name, String email, String howFound, String message)
    {
        try {
            MongoCursor<Document> doc = collectionContactRequest.find().iterator();
            Document d1 = new Document();
            d1.append("name", name);
            d1.append("email", email);
            d1.append("howFound", howFound);
            d1.append("message", message );

            System.out.println("addContactRequest is okey");
            collectionContactRequest.insertOne(d1);

        } catch (Exception e) {
            System.out.println("addContactRequest has errors");
        }
    }

    //---------------------------------------------------------------------------------------------------
    // CurrentSystemInfoController
    //---------------------------------------------------------------------------------------------------
    /**
     * This is the method for getting current course name
     * @param id the id: process for finding the document
     * @return the current course name
     */
    public String getCurrentCourseName(String id)
    {
        try {
            Document doc = collectionCurrentSystemInfo.find(new Document("id", id)).first();

            if (doc != null) {
                return doc.getString("course");
            } else {
                return " ";
            }

        } catch (Exception e) {
            System.out.println("getCurrentCourseName hatalı");
        }
        return " ";
    }


    /**
     * This is the method for getting current semester
     * @param id the id: process for finding the document
     * @return the current course semester
     */
    public String getCurrentSemester(String id)
    {
        try {
            Document doc = collectionCurrentSystemInfo.find(new Document("id", id)).first();

            if (doc != null) {
                return doc.getString("semester");
            } else {
                return " ";
            }

        } catch (Exception e) {
            System.out.println("getCurrentSemester hatalı");
        }
        return " ";
    }

    /**
     * This is the method for changing current course name
     * @param courseName the name of the course
     */
    public void changeCurrentCourseName(String courseName)
    {
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", "currentSystemInfo");

            MongoCursor<Document> cursor = collectionCurrentSystemInfo.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionCurrentSystemInfo.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> processes = new ArrayList(doc.next().values());

                if ((processes.get(1).equals("currentSystemInfo")))
                {
                    Document str = cursor.next();
                    Document found = (Document) collectionCurrentSystemInfo.find(new Document("id", "currentSystemInfo")).first();

                    Bson updateMember = new Document("course", courseName);
                    Bson updateOperation = new Document("$set", updateMember);
                    collectionCurrentSystemInfo.findOneAndUpdate(found, updateOperation);
                    System.out.println("changeCurrentCourseName ekleme tamam");
                }
            }
        } catch (Exception e) {
            System.out.println("changeCurrentCourseName olmadı");
        }
    }
    /**
     * This is the method for changing current semester
     * @param semester the current semester name
     */
    public void changeCurrentSemester(String semester)
    {
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", "currentSystemInfo");

            MongoCursor<Document> cursor = collectionCurrentSystemInfo.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionCurrentSystemInfo.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> processes = new ArrayList(doc.next().values());

                if ((processes.get(1).equals("currentSystemInfo")))
                {
                    Document str = cursor.next();
                    Document found = (Document) collectionCurrentSystemInfo.find(new Document("id", "currentSystemInfo")).first();

                    Bson updateMember = new Document("semester", semester);
                    Bson updateOperation = new Document("$set", updateMember);
                    collectionCurrentSystemInfo.findOneAndUpdate(found, updateOperation);
                    System.out.println("changeCurrentSemester ekleme tamam");
                }
            }
        } catch (Exception e) {
            System.out.println("changeCurrentSemester olmadı");
        }
    }

    //---------------------------------------------------------------------------------------------------
    // ProjectRatingController
    //---------------------------------------------------------------------------------------------------

    /**
     * This is the method for giving a rate to project
     * @param groupName the group name of the project
     * @param rate the rate which is given to project
     */
    public void giveRateToProject(String groupName, int rate)
    {
        if (getGroup(groupName) == null) {
            System.out.println("giveRateToProject ekleme olmadı");
        }
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("groupName", groupName);

            MongoCursor<Document> cursor = collectionProjectRates.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionProjectRates.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> groups = new ArrayList(doc.next().values());

                if ((groups.get(1).equals(groupName)))
                {
                    Document str = cursor.next();
                    Document found = (Document) collectionProjectRates.find(new Document("groupName", groupName)).first();

                    int projectRate = (int)found.get((String)"rate") + rate;
                    int projectRaterCount = (int)found.get((String)"raterCount") + 1;
                    System.out.println(projectRate);
                    System.out.print(projectRaterCount);
                    Bson updateMember = new Document("rate", projectRate);
                    Bson updateOperation = new Document("$set", updateMember);
                    collectionProjectRates.findOneAndUpdate(found, updateOperation);
                    found = (Document) collectionProjectRates.find(new Document("groupName", groupName)).first();
                    Bson updateMember2 = new Document("raterCount", projectRaterCount);
                    Bson updateOperation2 = new Document("$set", updateMember2);
                    collectionProjectRates.findOneAndUpdate(found, updateOperation2);
                    System.out.println("giveRateToProject ekleme tamam");
                }
            }
        } catch (Exception e) {
            System.out.println("giveRateToProject olmadı");
        }
    }


    /**
     * This is the method for getting rate of a project
     * @param groupName the group name of the project
     * @return the overall rate of the project
     */
    public double getRateOfProject(String groupName)
    {
        try {
            Document doc = collectionProjectRates.find(new Document("groupName", groupName)).first();

            if (doc != null) {
                int rate = doc.getInteger("rate");
                int raterCount = doc.getInteger("raterCount");
                return rate/raterCount;
            } else {
                return -1;
            }

        } catch (Exception e) {
            System.out.println("getRateOfProject hatalı");
        }
        return -1;
    }
    //---------------------------------------------------------------------------------------------------
    // ProcessController
    //---------------------------------------------------------------------------------------------------

    /**
     * This is the method for changing group formation status
     * @param status the status of the group formation
     */
    public void changeGroupFormation(String status)
    {
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", "process");

            MongoCursor<Document> cursor = collectionProcess.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionProcess.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> processes = new ArrayList(doc.next().values());

                if ((processes.get(1).equals("process")))
                {
                    Document str = cursor.next();
                    Document found = (Document) collectionProcess.find(new Document("id", "process")).first();

                    Bson updateMember = new Document("groupFormation", status);
                    Bson updateOperation = new Document("$set", updateMember);
                    collectionProcess.findOneAndUpdate(found, updateOperation);
                    System.out.println("changeGroupFormation ekleme tamam");
                }
            }
        } catch (Exception e) {
            System.out.println("changeGroupFormation olmadı");
        }
    }

    /**
     * This is the method for changing peer review  status
     * @param status the status of the peer review
     */
    public void changePeerReview(String status)
    {
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", "process");

            MongoCursor<Document> cursor = collectionProcess.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionProcess.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> processes = new ArrayList(doc.next().values());

                if ((processes.get(1).equals("process")))
                {
                    Document str = cursor.next();
                    Document found = (Document) collectionProcess.find(new Document("id", "process")).first();

                    Bson updateMember = new Document("peerReview", status);
                    Bson updateOperation = new Document("$set", updateMember);
                    collectionProcess.findOneAndUpdate(found, updateOperation);
                    System.out.println("changePeerReview ekleme tamam");
                }
            }
        } catch (Exception e) {
            System.out.println("changePeerReview olmadı");
        }
    }

    /**
     * This is the method for changing course review status
     * @param status the status of the course review
     */
    public void changeCourseReview(String status)
    {
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", "process");

            MongoCursor<Document> cursor = collectionProcess.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionProcess.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> processes = new ArrayList(doc.next().values());

                if ((processes.get(1).equals("process")))
                {
                    Document str = cursor.next();
                    Document found = (Document) collectionProcess.find(new Document("id", "process")).first();

                    Bson updateMember = new Document("courseReview", status);
                    Bson updateOperation = new Document("$set", updateMember);
                    collectionProcess.findOneAndUpdate(found, updateOperation);
                    System.out.println("changePeerReview ekleme tamam");
                }
            }
        } catch (Exception e) {
            System.out.println("changePeerReview olmadı");
        }
    }

    /**
     * This is the method for changing project rating status
     * @param status the status of the project rating
     */
    public void changeProjectRating(String status)
    {
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", "process");

            MongoCursor<Document> cursor = collectionProcess.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionProcess.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> processes = new ArrayList(doc.next().values());

                if ((processes.get(1).equals("process")))
                {
                    Document str = cursor.next();
                    Document found = (Document) collectionProcess.find(new Document("id", "process")).first();

                    Bson updateMember = new Document("projectRating", status);
                    Bson updateOperation = new Document("$set", updateMember);
                    collectionProcess.findOneAndUpdate(found, updateOperation);
                    System.out.println(" changeProjectRating ekleme tamam");
                }
            }
        } catch (Exception e) {
            System.out.println("changeProjectRating olmadı");
        }
    }

    /**
     * This is the method for getting group formation status
     * @param id the id of the document which holds the group formation status
     * @return the group formation status
     */
    public String getGroupFormationStatus(String id)
    {
        try {
            Document doc = collectionProcess.find(new Document("id", id)).first();

            if (doc != null) {
                return doc.getString("groupFormation");
            } else {
                return null;
            }

        } catch (Exception e) {
            System.out.println("getGroupFormationStatus hatalı");
        }
        return null;
    }


    /**
     * This is the method for getting peer review status
     * @param id the id of the document which holds the peer review status
     * @return the peer review status
     */
    public String isPeerReviewOnOrOff(String id)
    {
        try {
            Document doc = collectionProcess.find(new Document("id", id)).first();

            if (doc != null) {
                return doc.getString("peerReview");
            } else {
                return null;
            }

        } catch (Exception e) {
            System.out.println("isPeerReviewOnOrOff hatalı");
        }
        return null;
    }

    /**
     * This is the method for getting course review status
     * @param id the id of the document which holds the course review status
     * @return the course review status
     */
    public String isCourseReviewOnOrOff(String id)
    {
        try {
            Document doc = collectionProcess.find(new Document("id", id)).first();

            if (doc != null) {
                return doc.getString("courseReview");
            } else {
                return null;
            }

        } catch (Exception e) {
            System.out.println("isPeerReviewOnOrOff hatalı");
        }
        return null;
    }

    /**
     * This is the method for getting project rating status
     * @param id the id of the document which holds the course review status
     * @return the project rating status
     */
    public String isProjectRatingOnOrOff(String id)
    {
        try {
            Document doc = collectionProcess.find(new Document("id", id)).first();

            if (doc != null) {
                return doc.getString("projectRating");
            } else {
                return null;
            }

        } catch (Exception e) {
            System.out.println("isProjectRatingOnOrOff hatalı");
        }
        return null;
    }

    //---------------------------------------------------------------------------------------------------
    // UserController
    //---------------------------------------------------------------------------------------------------

    /**
     * This is the method for assigning role to user
     * @param schoolID the id of the user
     * @param userRole the role of the user which will be assigned
     */
    public void assignRoleToUser(int schoolID, String userRole)
    {
        if (getUser(schoolID) == null) {
            System.out.println("assignRoleToUser ekleme olmadı");
        }
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", schoolID);

            MongoCursor<Document> cursor = collectionUser.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionUser.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> users = new ArrayList(doc.next().values());

                if ((users.get(5).equals(schoolID)))
                {
                    Document str = cursor.next();
                    Document found = (Document) collectionUser.find(new Document("id", schoolID)).first();

                    Bson updateMember = new Document("userRole", userRole);
                    Bson updateOperation = new Document("$set", updateMember);
                    collectionUser.findOneAndUpdate(found, updateOperation);
                    System.out.println("assignRoleToUser ekleme tamam");
                    return;
                }


            }
        } catch (Exception e) {
            System.out.println("assignRoleToUser olmadı");
        }
        System.out.println("assignRoleToUser olmadı");
    }


    //---------------------------------------------------------------------------------------------------
    // signUpController
    //---------------------------------------------------------------------------------------------------


    /**
     * This is the method for inserting user to system
     * @param user the user who will be inserted
     * @return true if user is inserted otherwise false
     */
    public boolean insertUser(User user) {
        // Uploading data to mongodb
        try {
            if (getUser(user.getSchoolId()) == null) {
                MongoCursor<Document> doc = collectionUser.find().iterator();
                Document d1 = new Document();
                d1.append("name", user.getName());
                d1.append("surname", user.getSurname());
                d1.append("email", user.getEmail());
                d1.append("password", user.getPassword());
                d1.append("id", user.getSchoolId());
                d1.append("userRole", user.getUserRole());

                System.out.println("ekleme tamam");
                collectionUser.insertOne(d1);
                return true;
            } else {
                System.out.println("ekleme olmadıı");
                return false;
            }

        } catch (Exception e) {
            System.out.println("insert user hatalı");
            // System.out.println(e);
            return false;
        }
    }

    /**
     * This is the method for hiding passwords
     * @param password which will turned to a code
     * @return string version of the code
     */
    public String secretPassword(String password) {
        String secretPassword;
        int hashCode = password.hashCode();
        secretPassword = String.valueOf(hashCode);
        return secretPassword;
    }

    /**
     * This is the method for getting the user from the system
     * @param id the id of the user which is searched
     * @return the user object including all information about the user
     */
    public User getUser(int id) {
        try {
            Document doc = collectionUser.find(new Document("id", id)).first();

            if (doc != null) {
                return new User(doc.getString("name"),
                        doc.getString("surname"),
                        doc.getString("email"),
                        doc.getString("password"),
                        doc.getInteger("id"),
                        doc.getString("userRole"));
            } else {
                return null;
            }

        } catch (Exception e) {
            System.out.println("get user hatalı");
        }
        return null;
    }

    //---------------------------------------------------------------------------------------------------
    // SectionController
    //---------------------------------------------------------------------------------------------------
    /**
     * This is the method for getting section of a student
     * @param schoolID the id of the student
     * @return the section number of the student
     */
    public int getSectionOfStudent(int schoolID) {
        ArrayList<Integer> allSections = getAllSectionNames();

        for (int i = 0; i < allSections.size(); i++) {
            int sectionNumber = allSections.get(i);
            ArrayList<Integer> sectionIDs = getAllStudentsIdFromSection(sectionNumber);

            for (int a = 0; a < sectionIDs.size(); a++) {
                if (sectionIDs.get(a).equals(schoolID)) {
                    return sectionNumber;
                }
            }
        }

        return -1;
    }

    /**
     * This is the method for getting all section of an instructor
     * @param instructorID the id of the instructor
     * @return list of section numbers
     */
    public ArrayList<Integer> getAllSectionsOfInstructor(int instructorID) {
        ArrayList<Integer> sections = new ArrayList<Integer>();

        MongoCursor<Document> doc = collectionSection.find().iterator();
        while (doc.hasNext()) {

            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            if (property1.get(3).equals(instructorID)) {
                System.out.println(property1.get(1));
                sections.add((int) property1.get(1));
            }
        }
        if (sections.size() != 0) {
            return sections;
        }
        return null;
    }

    /**
     * This is the method for creating a section
     * @param sectionNumber the new section number
     * @param instructorID the id of the instructor with the new section
     * @return true if section is created otherwise false
     */
    public boolean createSection(int sectionNumber, int instructorID) {

        Document doc = collectionSection.find(new Document("sectionNumber", sectionNumber)).first();
        User u = getUser(instructorID);
        if (doc != null  && u != null && u.getUserRole().equals("instructor")) {
            return false;
        }
        MongoCursor<Document> doc1 = collectionSection.find().iterator();
        Document d1 = new Document();
        d1.append("sectionNumber", sectionNumber);
        d1.append("groupIds", new ArrayList<String>());
        d1.append("instructor", instructorID);
        d1.append("TAlist", new ArrayList<Integer>());
        d1.append("students", new ArrayList<Integer>());
        collectionSection.insertOne(d1);
        System.out.println("Section ekleme tamam. Section: " + sectionNumber + " InstructorID: " + instructorID);
        return true;

    }

    /**
     * This is the method for inserting user to a section
     * @param sectionNumber the new section number
     * @param schoolID the id of the user
     * @param sectionNumber the number of the new section
     * @return true if user is inserted to section otherwise false
     */
    public boolean insertUserToSection(int schoolID, int sectionNumber) {

        User u = getUser(schoolID);
        String userRole = u.getUserRole();
        if (u == null ) {
            System.out.println("insertUserToSection ekleme olmadı");
            return false;
        }
        if (!userRole.equals("user") && !userRole.equals("TA")) {
            System.out.println("insertUserToSection ekleme olmadi. Orgenci ya user, ya instr, ya da TA");
            return false;
        }
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("sectionNumber", sectionNumber);

            MongoCursor<Document> cursor = collectionSection.find(whereQuery).iterator();

            MongoCursor<Document> doc = collectionSection.find().iterator();
            while (doc.hasNext()) {
                ArrayList<Object> sections = new ArrayList(doc.next().values());

                if ((int) (sections.get(1)) == sectionNumber) {
                    Document str = cursor.next();
                    List<Integer> list;
                    if (userRole.equals("TA")) {
                        list = (List<Integer>) str.get("TAlist");
                    } else {
                        list = (List<Integer>) str.get("students");
                    }

                    if (list.contains(schoolID)) {
                        // user already exist
                        System.out.println(" ekleme olmadı");
                        return false;
                    }
                    list.add(schoolID);
                    Document found = (Document) collectionSection.find(new Document("sectionNumber", sectionNumber)).first();
                    if (userRole.equals("TA")) {
                        Bson updateMember = new Document("TAlist", list);
                        Bson updateOperation = new Document("$set", updateMember);
                        collectionSection.findOneAndUpdate(found, updateOperation);
                        System.out.println("TA ekleme tamam");
                        return true;
                    } else if (userRole.equals("user")) {
                        Bson updateMember = new Document("students", list);
                        Bson updateOperation = new Document("$set", updateMember);
                        collectionSection.findOneAndUpdate(found, updateOperation);
                        System.out.println("Student ekleme tamam");
                        assignRoleToUser(schoolID, "student");
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error" + e);
            return false;
        }
        System.out.println("Array ekleme yapılamadı");
        return false;
    }

    /**
     * This is the method for getting groups of a section
     * @param sectionNumber the section number
     * @return list of the group names in the section
     */
    public ArrayList<String> getGroupsOfSection(int sectionNumber)
    {
        MongoCursor<Document> doc = collectionSection.find().iterator();

        while (doc.hasNext()) {
            //System.out.println(doc.next().values()); // taking full data
            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            if (property1.get(1).equals(sectionNumber)) {
                return ((ArrayList<String>) (property1.get(2)));
            }
        }

        return null;
    }

    /**
     * This is the method for getting all section names
     * @return list of all section names
     */
    public ArrayList<Integer> getAllSectionNames()
    {
        ArrayList<Integer> allSections = new ArrayList<Integer>();

        MongoCursor<Document> doc = collectionSection.find().iterator();
        while (doc.hasNext()) {

            ArrayList<Object> property1 = new ArrayList(doc.next().values());
            allSections.add((int)property1.get(1));
        }
        if(allSections.size() != 0)
        {
            return allSections;
        }
        return null;
    }


    //---------------------------------------------------------------------------------------------------
    // GroupFormationController
    //---------------------------------------------------------------------------------------------------

    /**
     * This is the method for getting number of students in a section
     * @param sectionID the id of the section
     * @return count of students
     */
    public int getNumberOfStudentsFromSection(int sectionID) {
        MongoCursor<Document> doc = collectionSection.find().iterator();

        while (doc.hasNext()) {
            //System.out.println(doc.next().values()); // taking full data
            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            if (property1.get(1).equals(sectionID)) {
                return ((ArrayList<Integer>) (property1.get(5))).size();
            }
        }
        return 0;
    }

    /**
     * This is the method for getting all students' id from a section
     * @param sectionID the id of the section
     * @return list of the ids in the section
     */
    public ArrayList<Integer> getAllStudentsIdFromSection(int sectionID) {
        ArrayList<Integer> allStudentsId = new ArrayList<Integer>();

        MongoCursor<Document> doc = collectionSection.find().iterator();

        while (doc.hasNext()) {
            //System.out.println(doc.next().values()); // taking full data
            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            if (property1.get(1).equals(sectionID)) {
                return ((ArrayList<Integer>) (property1.get(5)));
            }
        }

        return null;
    }

    /**
     * This is the method for inserting student to a group
     * @param groupID the id of the group
     * @param studentID the id of the student
     * @param sectionID the id of the section
     * @return true if student is inserted to a group
     */
    public boolean insertStudentToGroup(String groupID, int studentID, int sectionID) {
        // User validation
        User user1 = getUser(studentID);
        if (user1 == null || !(user1.getUserRole().equals("student"))) {
            return false;
        }
        // Section validation
        Section sec1 = getSection(sectionID);
        if (sec1 == null) {
            return false;
        }
        // Group validation
        boolean groupExist = false;
        for (int i = 0; i < sec1.getGroupIds().size(); i++) {

            if (sec1.getGroupIds().get(i).equals(groupID)) {
                groupExist = true;
                break;
            }
        }
        if (!(groupExist)) {
            return false;
        }

        if (userHasGroup(studentID)) {
            return false;
        }

        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("groupName", groupID);
            MongoCursor<Document> cursor = collectionGroups.find(whereQuery).iterator();


            Document str = cursor.next();
            ArrayList<Integer> list = (ArrayList<Integer>) str.get("groupMembersId");
            list.add(studentID);
            Document found = (Document) collectionGroups.find(new Document("groupName", groupID)).first();
            Bson updateMember = new Document("groupMembersId", list);
            Bson updateOperation = new Document("$set", updateMember);
            collectionGroups.findOneAndUpdate(found, updateOperation);
            System.out.println("student ekleme tamam");

            BasicDBObject whereQuery1 = new BasicDBObject();
            whereQuery1.put("id", studentID);

            MongoCursor<Document> cursor1 = collectionUser.find(whereQuery1).iterator();

            MongoCursor<Document> doc1 = collectionUser.find().iterator();
            while (doc1.hasNext()) {
                ArrayList<Object> users = new ArrayList(doc1.next().values());

                if (users.get(5).equals(studentID)) {

                    Document found1 = (Document) collectionUser.find(new Document("id", studentID)).first();

                    Bson updateMember1 = new Document("groupName", groupID);
                    Bson updateOperation1 = new Document("$set", updateMember1);
                    collectionUser.findOneAndUpdate(found1, updateOperation1);
                    System.out.println("Student grupname eklendi");
                    return true;
                }
            }
        } catch (Exception e) {
            System.out.println("insert student to group hatalı");
            return false;
        }
        return false;
    }

    /**
     * This is the method for checking if a user has a group or not
     * @param studentID the id of the student
     * @return true if user has group, false otherwise
     */
    public boolean userHasGroup(int studentID) {
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", studentID);

            MongoCursor<Document> cursor = collectionUser.find(whereQuery).iterator();

            while (cursor.hasNext()) {
                ArrayList<Object> user = new ArrayList(cursor.next().values());

                if (!(user.get(7).equals(""))) {
                    System.out.println("User has group");
                    return true;
                }

            }
        }catch(Exception e)
        {
            return false;
        }
        return false;
    }

    /**
     * This is the method for creating a group
     * @param groupID the id of the group
     * @return true if group is created otherwise false
     */
    public boolean createGroup(String groupID)
    {
        Group group = getGroup(groupID);
        int sectionNumber = (groupID.charAt(groupID.length() - 2) - '0');
        if(group != null)
        {
            System.out.println("group already exist");
            return false;
        }
        try {
            MongoCursor<Document> doc = collectionGroups.find().iterator();
            Document d1 = new Document();
            d1.append("groupName",groupID);
            d1.append("groupMembersId", new ArrayList<Integer>());
            d1.append("peerReviews", new ArrayList<String>());
            collectionGroups.insertOne(d1);
            System.out.println(" Group ekleme tamam");

            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("sectionNumber", sectionNumber);

            MongoCursor<Document> cursor = collectionSection.find(whereQuery).iterator();
            Document str = cursor.next();
            List<String> list;

            list = (List<String>)str.get("groupIds");

            list.add(groupID);
            Document found = (Document) collectionSection.find(new Document("sectionNumber", sectionNumber)).first();

            Bson updateMember = new Document("groupIds", list);
            Bson updateOperation = new Document("$set", updateMember);
            collectionSection.findOneAndUpdate(found,updateOperation);
            System.out.println("Group IDs ekleme tamam");
            return true;
        } catch (Exception e) {
            System.out.println("insert group hatalı");
            return false;
        }

    }

    /**
     * This is the method for getting the section with id
     * @param sectionID the id of the section
     * @return the section object including all its' information
     */
    public Section getSection(int sectionID)
    {
        try{
            Document doc = collectionSection.find( new Document("sectionNumber", sectionID)).first();
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("sectionNumber", sectionID);

            if(doc != null)
            {
                MongoCursor<Document> cursor = collectionSection.find(whereQuery).iterator();
                Document str = cursor.next();
                List<String>  list = (ArrayList<String>)str.get("groupIds");
                List<Integer> lis2 = (ArrayList<Integer>)str.get("TAlist");


                return new Section(doc.getInteger("sectionNumber"),
                        (ArrayList<String>)str.get("groupIds"),
                        doc.getInteger("instructor"),
                        (ArrayList<Integer>)str.get("TAlist"),
                        (ArrayList<Integer>)str.get("students"),
                        "");
            }
        }catch(Exception e)
        {
            System.out.println("get section hatalı");
        }
        return null;

    }

    /**
     * This is the method for getting the group with id
     * @param groupID the id of the group
     * @return the group object including all its' information
     */
    public Group getGroup(String groupID)
    {
        try{
            Document doc = collectionGroups.find( new Document("groupName", groupID)).first();

            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("groupName", groupID);

            if(doc != null)
            {
                MongoCursor<Document> cursor = collectionGroups.find(whereQuery).iterator();
                Document str = cursor.next();
                return new Group((ArrayList<Integer>)str.get("groupMembersId"),
                        doc.getString("groupName"),
                        (ArrayList<String>)str.get("peerReviews"));
            }
            else
            {
                return null;
            }

        }catch(Exception e)
        {
            System.out.println("get group hatalı");
        }
        return null;
    }

    /**
     * This is the method for creating a group for a user
     * @param sectionID the id of the section which the group will be in
     * @param studentID the id of the student who creates the group
     * @return true if the group is created otherwise false
     */
    public boolean createGroupByUser(int sectionID, int studentID)
    {
        if(userHasGroup(studentID))
        {
            return false;
        }
        Group g = null;
        char ch;
        for( ch = 'a'; ch <= 'z'; ch++)
        {
            g = getGroup("CS319-" + sectionID + ch);
            if(g == null)
            {
                createGroup("CS319-" + sectionID + ch);
                insertStudentToGroup("CS319-" + sectionID + ch,studentID,sectionID);
                return true;
            }
        }
        return false;
    }

    /**
     * This is the method for removing a user from a group
     * @param studentID the id of the student who will be removed
     * @return true if user is removed false otherwise
     */
    public boolean removeUserFromGroup(int studentID) {
        // student group
        try {
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("id", studentID);

            MongoCursor<Document> cursor = collectionUser.find(whereQuery).iterator();
            String groupName = "";
            while (cursor.hasNext()) {
                ArrayList<Object> user = new ArrayList(cursor.next().values());
                groupName = user.get(7).toString();
                if(groupName.equals("")) {
                    System.out.println("group does not exits in use");
                    return false;
                }
            }

            // Delete groupID from User
            Document found = (Document) collectionUser.find(new Document("id", studentID)).first();
            Bson updateMember = new Document("groupName", "");
            Bson updateOperation = new Document("$set", updateMember);
            collectionUser.findOneAndUpdate(found, updateOperation);
            System.out.println("userdan grup silindi");

            // Delete user from Group
            try {
                whereQuery = new BasicDBObject();
                whereQuery.put("groupName", groupName);

                cursor = collectionGroups.find(whereQuery).iterator();

                MongoCursor<Document> doc = collectionGroups.find().iterator();
                while (doc.hasNext()) {
                    ArrayList<Object> groups = new ArrayList(doc.next().values());

                    if (groups.get(1).equals(groupName)) {
                        System.out.println("Evet");
                        Document str = cursor.next();
                        List<Integer> list = (List<Integer>) str.get("groupMembersId");

                        ArrayList<Integer> newList = new ArrayList<>();
                        for(int i=0; i<list.size(); i++) {
                            if(!list.get(i).equals(studentID)) {
                                newList.add(list.get(i));
                            }
                        }

                        found = (Document) collectionGroups.find(new Document("groupName", groupName)).first();
                        updateMember = new Document("groupMembersId", newList);
                        updateOperation = new Document("$set", updateMember);
                        collectionGroups.findOneAndUpdate(found, updateOperation);
                        System.out.println("ogrenci silindi.");
                        if(newList.size() == 0) {
                            removeGroup(groupName);
                        }
                        return true;
                    }
                }
            }catch (Exception e) {
                System.out.println(e);
                return false;
            }
        }catch(Exception e)
        {
            System.out.println(e);
            return false;
        }
        return false;
        // group collection student
    }

    /**
     * This is the method for removing a group
     * @param groupName the group name which will be removed
     * @return true if the group is removed false otherwise
     */
    public boolean removeGroup(String groupName) {
        try {
            collectionGroups.deleteOne(Filters.eq("groupName", groupName));

            int section = groupName.charAt( groupName.length()-2) - '0';
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("sectionNumber", section);
            MongoCursor<Document> cursor = collectionSection.find(whereQuery).iterator();

            Document str = cursor.next();
            ArrayList<String> list = (ArrayList<String>) str.get("groupIds");
            ArrayList<String> newList = new ArrayList<String>();
            for(int i=0; i<list.size(); i++) {
                if(!list.get(i).equals(groupName)) {
                    newList.add(list.get(i));
                }
            }
            Document found = (Document) collectionSection.find(new Document("sectionNumber", section)).first();
            Bson updateMember = new Document("groupIds", newList);
            Bson updateOperation = new Document("$set", updateMember);
            collectionSection.findOneAndUpdate(found, updateOperation);
            System.out.println("grup silme tmm sectiondan");
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
        return false;
    }

    //---------------------------------------------------------------------------------------------------
    // PeerReviewController
    //---------------------------------------------------------------------------------------------------


    /**
     * This is the method for inserting open ended question
     * @param question the string version of question
     * @return true if question is inserted
     */
    public boolean insertOpenEndedQuestion(String question)
    {
        // Uploading data to mongodb
        try {

            MongoCursor<Document> doc = collectionPeerReviewQuestions.find().iterator();
            Document d1 = new Document();
            d1.append("questionType", "open-ended");
            d1.append("question", question);
            System.out.println("insertOpenEndedQuestion addition okey");
            collectionPeerReviewQuestions.insertOne(d1);
            return true;

        }catch (Exception e) {
            System.out.println("insertOpenEndedQuestion  hatalı");
            // System.out.println(e);
            return false;
        }
    }

    /**
     * This is the method for inserting multiple choice question
     * @param question the string version of question
     * @param choices the lis of the choices
     * @return true if question is inserted
     */
    public boolean insertMultipleChoiceQuestion(String question, ArrayList<String> choices)
    {
        // Uploading data to mongodb
        try {
            MongoCursor<Document> doc = collectionPeerReviewQuestions.find().iterator();
            Document d1 = new Document();
            d1.append("questionType", "multiple-choice");
            d1.append("question", question);
            d1.append("choices",choices);
            System.out.println("insertMultipleChoiceQuestion addition okey");
            collectionPeerReviewQuestions.insertOne(d1);
            return true;

        }catch (Exception e) {
            System.out.println("insertMultipleChoiceQuestion  hatalı");
            // System.out.println(e);
            return false;
        }
    }

    /**
     * This is the method for inserting point question
     * @param question the string version of question
     * @param outOfGrade the max grade of the question
     * @return true if question is inserted
     */
    public boolean insertPointQuestion(String question, int outOfGrade)
    {
        // Uploading data to mongodb
        try {
            MongoCursor<Document> doc = collectionPeerReviewQuestions.find().iterator();
            Document d1 = new Document();
            d1.append("questionType", "point");
            d1.append("question", question);
            d1.append("outOfGrade", outOfGrade);
            System.out.println("insertPointQuestion addition okey");
            collectionPeerReviewQuestions.insertOne(d1);
            return true;

        }catch (Exception e) {
            System.out.println("insertPointQuestion  hatalı");
            // System.out.println(e);
            return false;
        }
    }

    /**
     * This is the method for getting peer review questions
     * @return list of questions
     */
    public ArrayList<Question> getPeerReviewQuestions() {
        ArrayList<Question> allQuestions = new ArrayList<Question>();

        MongoCursor<Document> doc = collectionPeerReviewQuestions.find().iterator();
        while (doc.hasNext()) {

            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            if (property1.get(1).equals("open-ended")) {
                OpenEndedQuestion openEnded = new OpenEndedQuestion(((String) (property1.get(2))));
                allQuestions.add(openEnded);
            } else if (property1.get(1).equals("multiple-choice")) {
                MultipleChoiceQuestion multipleChoice = new MultipleChoiceQuestion((String) (property1.get(2)), (ArrayList<String>) property1.get(3));
                allQuestions.add(multipleChoice);
            } else if (property1.get(1).equals("point")) {
                PointQuestion point = new PointQuestion((String) (property1.get(2)), (int) (property1.get(3)));
                allQuestions.add(point);
            }
        }
        if(allQuestions.size() != 0)
        {
            return allQuestions;
        }
        return null;
    }

    /**
     * This is the method for getting group of a student
     * @param studentID the id of the student
     * @return group name
     */
    public String getGroupNameFromStudent(int studentID)
    {
        Document doc = collectionUser.find(new Document("id", studentID)).first();
        if (doc != null) {
            return doc.getString("groupName");
        } else {
            return "";
        }
    }

    /**
     * This is the method for give answer to questions
     * @param giverId the id of the giver
     * @param receiverId the id of the receiver
     * @param answer the list of the answers
     * @return true if method is succesful
     */
    public boolean giveAnswerQuestions(int giverId,int receiverId, String answer)
    {
        if(getGroupNameFromStudent(giverId).equals(""))
        {
            System.out.println("öğrencinin grubu yok");
            return false;
        }
        else if (!getGroupNameFromStudent(giverId).equals(getGroupNameFromStudent(receiverId)))
        {
            System.out.println("öğrenciler aynı grupta değil");
            return false;
        }
        try {
            MongoCursor<Document> doc = collectionPeerReviewAnswer.find().iterator();
            Document d1 = new Document();
            d1.append("groupName", getGroupNameFromStudent(giverId));
            d1.append("giver-id", giverId);
            d1.append("receiver-id", receiverId);
            d1.append("answers", answer);
            System.out.println("giveAnswerQuestions addition okey");
            collectionPeerReviewAnswer.insertOne(d1);
            return true;
        }catch (Exception e) {
            System.out.println("giveAnswerQuestions  hatalı");
            return false;
        }
    }

    /**
     * This is the method for getting peer review answers
     * @param giverID the id of the giver
     * @param receiverID the id of the receiver
     * @return list of the answers
     */
    public String getPeerReviewAnswers(int giverID,int receiverID)
    {
        String allPeerReviewAnswers = "";

        MongoCursor<Document> doc = collectionPeerReviewAnswer.find().iterator();
        while (doc.hasNext()) {

            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            if(property1.get(2).equals(giverID) && property1.get(3).equals(receiverID))
            {
                allPeerReviewAnswers =(String)(property1.get(4));
            }
        }
            return allPeerReviewAnswers;
    }


    //---------------------------------------------------------------------------------------------------
    // ProfileController
    //---------------------------------------------------------------------------------------------------

    /**
     * This is the method for getting student information
     * @param studentID the id of the student
     * @return student object includes all info
     */
    public Student getStudentInformation(int studentID)
    {
        User u = getUser(studentID);
        if(u == null)
        {
            return null;
        }
        return new Student( u.getName(), u.getSurname(), u.getEmail(), u.getPassword(),u.getSchoolId(),
                (getGroupNameFromStudent(studentID).charAt(getGroupNameFromStudent(studentID).length()-2))-'0', getGroupNameFromStudent(studentID));
    }

    /**
     * This is the method for getting instructor information
     * @param instructorID the id of the instructor
     * @return instructor object includes all info
     */
    public Instructor getInstructorInformation (int instructorID) {
        User u = getUser(instructorID);
        if (u == null) {
            return null;
        }
        ArrayList<Integer> instructorSections = new ArrayList<Integer>();
        ArrayList<ArrayList<Integer>> TAs = new ArrayList<ArrayList<Integer>>();

        BasicDBObject whereQuery = new BasicDBObject();
        whereQuery.put("instructor", instructorID);

        MongoCursor<Document> cursor = collectionSection.find(whereQuery).iterator();
        while (cursor.hasNext()) {
            ArrayList<Object> section = new ArrayList(cursor.next().values());
            instructorSections.add((Integer) section.get(1));
            TAs.add((ArrayList<Integer>)section.get(4));
        }
        return new Instructor(u.getName(), u.getSurname(), u.getEmail(), u.getPassword(), u.getSchoolId(),
                instructorSections, TAs);
    }

    /**
     * This is the method for getting TA information
     * @param TAid the id of the TA
     * @return TA object includes all info
     */
    public TA getTAInformation(int TAid)
    {
        User u = getUser(TAid);
        if (u == null) {
            return null;
        }
        ArrayList<Integer> TaSections = new ArrayList<Integer>();

        MongoCursor<Document> cursor = collectionSection.find().iterator();
        while (cursor.hasNext()) {
            ArrayList<Object> section = new ArrayList(cursor.next().values());
            for(int i = 0; i < ((ArrayList<Integer>)(section.get(4))).size(); i++)
            {
                if( ((ArrayList<Integer>)(section.get(4))).get(i).equals(TAid))
                {
                    TaSections.add((int) section.get(1));
                }
            }
        }
        return new TA(u.getName(), u.getSurname(), u.getEmail(),u.getPassword(),u.getSchoolId(),TaSections);
    }

    /**
     * This is the method for getting a peer reviews about a specific student
     * @param receiverID the student id
     * @return the hash table the reviewer ids with their answers
     */
    public  Hashtable<Integer,ArrayList<String >> getSpecificPeerReviewOfStudent(int receiverID)
    {
        Hashtable<Integer,ArrayList<String> > peerReviewsOfStudent = new Hashtable<>();

        MongoCursor<Document> doc = collectionPeerReviewAnswer.find().iterator();

        while (doc.hasNext()) {
            //System.out.println(doc.next().values()); // taking full data
            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            if (property1.get(3).equals(receiverID)) {
                peerReviewsOfStudent.put((Integer) property1.get(2), (ArrayList<String>) property1.get(4));
            }
        }
        if(peerReviewsOfStudent.size() == 0)
        {
            return null;
        }

        return peerReviewsOfStudent;
    }

    //-------------------------------------------------------------------------------------
    // ArtifactReviewController
    //-------------------------------------------------------------------------------------

    /**
     * This is the method for giving artifact review
     * @param groupName the name of the group
     * @param artifactType the type of the artifact
     * @param answer the review
     * @param giverID the id of the review giver
     * @return true if the method is succesful
     */
    public boolean giveArtifactReviewToGroup(String groupName, String artifactType, String answer, int giverID)
    {
        Group group = getGroup(groupName);
        for(int i = 0; i < group.getStudentIDs().size(); i++)
        {
            if(group.getStudentIDs().get(i).equals(giverID))
            {
                return false;
            }
        }

        try {
            MongoCursor<Document> doc = collectionArtifactReviews.find().iterator();
            Document d1 = new Document();
            d1.append("groupName", groupName);
            d1.append("giver-id", giverID);
            d1.append("artifact-type", artifactType);
            d1.append("answers", answer);
            System.out.println("giveArtifactReviewToGroup addition okey");
            collectionArtifactReviews.insertOne(d1);
            return true;
        }catch (Exception e) {
            System.out.println("giveArtifactReviewToGroup  hatalı");
            return false;
        }

    }

    /**
     * This is the method for getting artifact reviews of a group
     * @param groupName the name of the group
     * @return hash table with the review givers' ids and answers
     */
    public String getArtifactReviewFromGroup(String groupName) throws JSONException {
        MongoCursor<Document> doc = collectionArtifactReviews.find().iterator();

        JSONArray reviews = new JSONArray();
        while (doc.hasNext()) {
            ArrayList<Object> property1 = new ArrayList(doc.next().values());
            if (property1.get(1).equals(groupName)) {
                JSONObject object = new JSONObject();

                object.put("giverID", (Integer) property1.get(2));
                object.put("artifactReview", (String) property1.get(4));
                object.put("artifactType", (String) property1.get(3));
                reviews.put(object);
            }

        }
//        if(artifactReviews.size() == 0)
//        {
//            return null;
//        }

        System.out.println("getArtifactReviewFromGroup çalışıyor");
        return reviews.toString();
    }

    //---------------------------------------------------------------------------------------------------
    // CourseReviewController
    //---------------------------------------------------------------------------------------------------


    /**
     * This is the method for inserting open ended question
     * @param question the string version of question
     * @return true if question is inserted
     */
    public boolean insertOpenEndedQuestionCourse(String question)
    {
        // Uploading data to mongodb
        try {
            MongoCursor<Document> doc = collectionCourseReviewQuestion.find().iterator();
            Document d1 = new Document();
            d1.append("questionType", "open-ended");
            d1.append("question", question);
            System.out.println("insertOpenEndedQuestionCourse addition okey");
            collectionCourseReviewQuestion.insertOne(d1);
            return true;

        }catch (Exception e) {
            System.out.println("insertOpenEndedQuestionCourse  hatalı");
            return false;
        }
    }

    /**
     * This is the method for inserting multiple choice question
     * @param question the string version of question
     * @param choices the choices of the question
     * @return true if question is inserted
     */
    public boolean insertMultipleChoiceQuestionCourse(String question, ArrayList<String> choices)
    {
        // Uploading data to mongodb
        try {
            MongoCursor<Document> doc = collectionCourseReviewQuestion.find().iterator();
            Document d1 = new Document();
            d1.append("questionType", "multiple-choice");
            d1.append("question", question);
            d1.append("choices",choices);
            System.out.println("insertMultipleChoiceQuestionCourse addition okey");
            collectionCourseReviewQuestion.insertOne(d1);
            return true;

        }catch (Exception e) {
            System.out.println("insertMultipleChoiceQuestionCourse  hatalı");
            // System.out.println(e);
            return false;
        }
    }

    /**
     * This is the method for inserting point question
     * @param question the string version of question
     * @param outOfGrade the max grade of the question
     * @return true if question is inserted
     */
    public boolean insertPointQuestionCourse(String question, int outOfGrade)
    {
        // Uploading data to mongodb
        try {
            MongoCursor<Document> doc = collectionCourseReviewQuestion.find().iterator();
            Document d1 = new Document();
            d1.append("questionType", "point");
            d1.append("question", question);
            d1.append("outOfGrade", outOfGrade);
            System.out.println("insertPointQuestionCourse addition okey");
            collectionCourseReviewQuestion.insertOne(d1);
            return true;

        }catch (Exception e) {
            System.out.println("insertPointQuestionCourse  hatalı");
            // System.out.println(e);
            return false;
        }
    }

    /**
     * This is the method for getting course review questions
     * @return list of questions
     */
    public ArrayList<Question> getCourseReviewQuestions() {
        ArrayList<Question> allQuestions = new ArrayList<Question>();

        MongoCursor<Document> doc = collectionCourseReviewQuestion.find().iterator();
        while (doc.hasNext()) {

            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            if (property1.get(1).equals("open-ended")) {
                OpenEndedQuestion openEnded = new OpenEndedQuestion(((String) (property1.get(2))));
                allQuestions.add(openEnded);
            } else if (property1.get(1).equals("multiple-choice")) {
                MultipleChoiceQuestion multipleChoice = new MultipleChoiceQuestion((String) (property1.get(2)), (ArrayList<String>) property1.get(3));
                allQuestions.add(multipleChoice);
            } else if (property1.get(1).equals("point")) {
                PointQuestion point = new PointQuestion((String) (property1.get(2)), (int) (property1.get(3)));
                allQuestions.add(point);
            }
        }
        if(allQuestions.size() != 0)
        {
            return allQuestions;
        }
        return null;
    }

    /**
     * This is the method for giving answers to questions
     * @param giverId the id of the giver
     * @param answer the list of the answer
     * @return true if method is succesful
     */
    public boolean giveAnswerQuestionsCourse(int giverId, ArrayList<String> answer)
    {
        try {
            MongoCursor<Document> doc = collectionCourseReviewAnswer.find().iterator();
            Document d1 = new Document();
            d1.append("giver-id", giverId);
            d1.append("answers", answer);
            System.out.println("giveAnswerQuestionsCourse addition okey");
            collectionCourseReviewAnswer.insertOne(d1);
            return true;
        }catch (Exception e) {
            System.out.println("giveAnswerQuestionsCourse  hatalı");
            return false;
        }
    }

    /**
     * This is the method for getting course review answers
     * @return list of answers
     */
    public ArrayList<ArrayList<String>> getCourseReviewAnswers()
    {
        ArrayList<ArrayList<String>> allCourseReviewAnswers = new ArrayList<ArrayList<String> >();

        MongoCursor<Document> doc = collectionCourseReviewAnswer.find().iterator();
        while (doc.hasNext()) {

            ArrayList<Object> property1 = new ArrayList(doc.next().values());

            allCourseReviewAnswers.add((ArrayList<String >)(property1.get(2)));
        }
        if(allCourseReviewAnswers.size() != 0)
        {
            return allCourseReviewAnswers;
        }
        return null;
    }
}
